function [crc1, crc2] = nbody(level, tmax, mc1, mc2, ns1, ns2, ...
    dir1, dir2, rc10, rc20, vc10, vc20, plotenable, avienable)
%   level:      determines the number of time steps (nt = 2^level + 1)
%   tmax:       maximum time
%   mc1:        mass of core 1
%   mc2:        mass of core 2
%   ns1:        number of stars orbiting core 1
%   ns2:        number of stars orbiting core 2
%   dir1:       direction of rotation of core 1 (1 for ccw, -1 for cw)
%   dir2:       direction of rotation of core 2 (1 for ccw, -1 for cw)
%   rc10:       1x3 initial position vector of core 1
%   rc20:       1x3 initial position vector of core 2
%   vc10:       1x3 initial velocity vector of core 1
%   vc20:       1x3 initial velocity vector of core 2
%   plotenable: 1 to enable plotting, 0 to disable
%   avienable:  1 to enable creation of avi video, 0 to disable

%   crc1:       1xnt vector of norm of position vectors of core 1 for
%               convergence testing
%   crc2:       1xnt vector of norm of position vectors of core 2 for
%               convergence testing

% =========================================================================
% Controls
% =========================================================================
dlim = 3000;
framefreq = 1;

% =========================================================================
% Variables
% =========================================================================
radmin = 100;
radmax = 300;

% =========================================================================
% Convergence Setup
% =========================================================================
nt = 2^level + 1;
crc1 = zeros(nt, 1);
crc2 = zeros(nt, 1);

tees = linspace(0, tmax, nt);
deltat = tees(2) - tees(1);

% =========================================================================
% Core Setup
% =========================================================================
rc1 = zeros(1,3,nt);
rc2 = zeros(1,3,nt);

rc1(1,:,1) = rc10;
rc2(1,:,1) = rc20;

rc1(1,:,2) = rc1(1,:,1) + deltat*vc10;
rc2(1,:,2) = rc2(1,:,1) + deltat*vc20;

% =========================================================================
% Star Setup
% =========================================================================
r1 = zeros(ns1,3,nt);
r2 = zeros(ns2,3,nt);

for n = 1:ns1
    r = (radmax - radmin)*rand() + radmin;
    theta = 2*pi*rand();
    rx = r*cos(theta);
    ry = r*sin(theta);
    r1(n,:,1) = rc1(1,:,1) + [rx, ry, 0];
    v = sqrt(mc1/r);
    r1(n,:,2) = r1(n,:,1) + dir1*deltat*(v/r*[-ry, rx, 0] + vc10);
end

for n = 1:ns2
    r = (radmax - radmin)*rand() + radmin;
    theta = 2*pi*rand();
    rx = r*cos(theta);
    ry = r*sin(theta);
    r2(n,:,1) = rc2(1,:,1) + [rx, ry, 0];
    v = sqrt(mc2/r);
    r2(n,:,2) = r2(n,:,1) + dir2*deltat*(v/r*[-ry, rx, 0] + vc20);
end

% =========================================================================
% Initialize Graphics
% =========================================================================
if ~plotenable
    avienable = 0;
end

avifilename = 'nbody.avi';
aviframerate = 25;

if avienable
    aviobj = VideoWriter(avifilename);
    open(aviobj);
end

% =========================================================================
% Program Engine
% =========================================================================
crc1(1) = norm(rc1(:,:,1));
crc2(1) = norm(rc2(:,:,1));

for n = 2:nt
    % ---------------------------------------------------------------------
    % graphics engine
    % ---------------------------------------------------------------------
    if (plotenable && mod(n,framefreq)==0)
        clf;

        hold on;
        axis square;
        box on;
        xlim([-dlim, dlim]);
        ylim([-dlim, dlim]);

        titlestr = sprintf('Step: %d   Time: %.1f', ...
            fix(tees(n) / deltat), tees(n));
        title(titlestr, 'FontSize', 16, 'FontWeight', 'bold', ...
            'Color', [0.25, 0.42, 0.31]);
        
        % plot cores
        plot(rc1(1,1,n), rc1(1,2,n), 'Marker', 'o', 'MarkerSize', 15, ...
            'MarkerEdgeColor', 'y', 'MarkerFaceColor', 'k');
     
        plot(rc2(1,1,n), rc2(1,2,n), 'Marker', 'o', 'MarkerSize', 15, ...
            'MarkerEdgeColor', 'y', 'MarkerFaceColor', 'k');
        
        % plot stars
        for i = 1:ns1
            plot(r1(i,1,n), r1(i,2,n), 'Marker', 'o', 'MarkerSize', 1, ...
               'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r');
        end
        
        for i = 1:ns2
            plot(r2(i,1,n), r2(i,2,n), 'Marker', 'o', 'MarkerSize', 1, ...
               'MarkerEdgeColor', 'b', 'MarkerFaceColor', 'b');
        end

        drawnow;
      
        if avienable
            if tees(n) == 0
                framecount = 5 * aviframerate ;
            else
                framecount = 1;
            end
            for iframe = 1 : framecount
                writeVideo(aviobj, getframe(gcf));
            end
        end
      
    end
    
    % ---------------------------------------------------------------------
    % physics engine
    % ---------------------------------------------------------------------
    % core physics
    ac1 = geta(rc1(:,:,n), rc2(:,:,n), mc2);
    ac2 = geta(rc2(:,:,n), rc1(:,:,n), mc1);
    
    rc1(:,:,n+1) = ac1*deltat^2 + 2*rc1(:,:,n) - rc1(:,:,n-1);
    rc2(:,:,n+1) = ac2*deltat^2 + 2*rc2(:,:,n) - rc2(:,:,n-1);
    
    % star physics
    a1 = geta(r1(:,:,n), rc1(:,:,n), mc1);
    a2 = geta(r1(:,:,n), rc2(:,:,n), mc2);
    a = a1 + a2;
    
    r1(:,:,n+1) = a*deltat^2 + 2*r1(:,:,n) - r1(:,:,n-1);
    
    a1 = geta(r2(:,:,n), rc1(:,:,n), mc1);
    a2 = geta(r2(:,:,n), rc2(:,:,n), mc2);
    a = a1 + a2;
    
    r2(:,:,n+1) = a*deltat^2 + 2*r2(:,:,n) - r2(:,:,n-1);
    
    % ---------------------------------------------------------------------
    % convergence engine
    % ---------------------------------------------------------------------
    crc1(n) = norm(rc1(:,:,n));
    crc2(n) = norm(rc2(:,:,n));
end

% =========================================================================
% Finalize Graphics
% =========================================================================
if avienable
    close(aviobj);
    fprintf('Created video file: %s\n', avifilename);
end

end