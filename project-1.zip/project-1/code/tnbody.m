clear; clc;
% =========================================================================
% Convergence Test
% =========================================================================
convenable = 1;

if convenable
    tmax = 300;

    mc1 = 10;
    mc2 = 5;
    ns1 = 0;
    ns2 = 0;
    dir1 = 1;
    dir2 = 1;

    d = 10;
    rc10 = [mc2/(mc1+mc2)*d, 0, 0];
    rc20 = [-mc1/(mc1+mc2)*d, 0, 0];

    vc10 = [0, sqrt(mc2*rc10(1))/d, 0];
    vc20 = [0, -sqrt(-mc1*rc20(1))/d, 0];

    % r vectors for different levels
    [r10,~] = nbody(10, tmax, mc1, mc2, ns1, ns2, dir1, dir2, rc10, rc20, vc10, vc20, 0, 0);
    [r11,~] = nbody(11, tmax, mc1, mc2, ns1, ns2, dir1, dir2, rc10, rc20, vc10, vc20, 0, 0);
    [r12,~] = nbody(12, tmax, mc1, mc2, ns1, ns2, dir1, dir2, rc10, rc20, vc10, vc20, 0, 0);
    [r13,~] = nbody(13, tmax, mc1, mc2, ns1, ns2, dir1, dir2, rc10, rc20, vc10, vc20, 0, 0);
    [r14,~] = nbody(14, tmax, mc1, mc2, ns1, ns2, dir1, dir2, rc10, rc20, vc10, vc20, 0, 0);

    % downsizing
    r11 = r11(1:2:end);
    r12 = r12(1:4:end);
    r13 = r13(1:8:end);
    r14 = r14(1:16:end);

    % plot of r vectors
    t = linspace(0, tmax, length(r10));

    figure(1);
    hold on;
    plot(t, r10, 'r');
    plot(t, r11, 'g');
    plot(t, r12, 'b');
    plot(t, r13, 'k');
    plot(t, r14, 'm');
    title('Radius of core about center of mass');
    xlabel('Time');
    ylabel('Radius');
    legend('level 10', 'level 11', 'level 12', 'level 13', 'level 14');

    % plot of level differences
    r10_11 = r10 - r11;
    r11_12 = r11 - r12;
    r12_13 = r12 - r13;
    r13_14 = r13 - r14;

    figure(2);
    hold on;
    plot(t, r10_11, 'r');
    plot(t, r11_12, 'g');
    plot(t, r12_13, 'b');
    plot(t, r13_14, 'k');
    title('Differences between levels of radius calculation');
    xlabel('Time');
    ylabel('Radius');
    legend('level 10-11', 'level 11-12', 'level 12-13', 'level 13-14');

    % plot of level differences rescaled
    r11_12 = 2*r11_12;
    r12_13 = 4*r12_13;
    r13_14 = 8*r13_14;

    figure(3);
    hold on;
    plot(t, r10_11, 'r');
    plot(t, r11_12, 'g');
    plot(t, r12_13, 'b');
    plot(t, r13_14, 'k');
    title('Differences between levels of radius calculation rescaled');
    xlabel('Time');
    ylabel('Radius');
    legend('1*level 10-11', '2*level 11-12', '4*level 12-13', '8*level 13-14');
end

% =========================================================================
% One Stationary Core With Many Stars
% =========================================================================
figure(4);
tmax = 300;

mc1 = 1000; mc2 = 0;
ns1 = 1000; ns2 = 0;
dir1 = 1; dir2 = 1;

rc10 = [0, 0, 0];
rc20 = [10000, 0, 0];

vc10 = [0, 0, 0];
vc20 = [0, 0, 0];

[~,~] = nbody(5, tmax, mc1, mc2, ns1, ns2, dir1, dir2, ...
    rc10, rc20, vc10, vc20, 0, 0);

% =========================================================================
% One Moving Core With Many Stars
% =========================================================================
tmax = 2000;

mc1 = 1000; mc2 = 0;
ns1 = 1000; ns2 = 0;
dir1 = 1; dir2 = 1;

rc10 = [-1000, -1000, 0];
rc20 = [10000, 0, 0];

vc10 = [1, 1, 0];
vc20 = [0, 0, 0];

[~,~] = nbody(8, tmax, mc1, mc2, ns1, ns2, dir1, dir2, ...
    rc10, rc20, vc10, vc20, 0, 0);

% =========================================================================
% Two Moving Cores With Many Stars
% =========================================================================
tmax = 4000;
 
mc1 = 1000; mc2 = 1000;
ns1 = 1000; ns2 = 1000;
dir1 = 1; dir2 = 1;
 
rc10 = [-500, -500, 0];
rc20 = [500, 500, 0];
 
vc10 = [1.05, 0, 0];
vc20 = [-1.05, 0, 0];
 
[~,~] = nbody(8, tmax, mc1, mc2, ns1, ns2, dir1, dir2, ...
    rc10, rc20, vc10, vc20, 0, 0);