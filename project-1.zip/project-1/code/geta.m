function a = geta(r, rc, mc)
%   r:  nx3 matrix of position vectors
%   rc: position vector of core
%   mc: mass of core

%   a:  nx3 matrix of acceleration vectors

    [n,~] = size(r);
    a = zeros(n, 3);
    for i = 1:n
        a(i,:) = mc/norm(rc-r(i,:))^3*(rc-r(i,:));
    end
end